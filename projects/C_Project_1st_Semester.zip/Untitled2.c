
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void save_score(const char *name, int attempts, double timeTaken) {
    FILE *file = fopen("leaderboard.txt", "a");
    if (file != NULL) {
        fprintf(file, "%s %d %.2f\n", name, attempts, timeTaken);
        fclose(file);
    }
}

void display_leaderboard() {
    char name[50];
    int attempts;
    double timeTaken;

    printf("\n--- Leaderboard ---\n");
    FILE *file = fopen("leaderboard.txt", "r");
    if (file == NULL) {
        printf("No scores available yet.\n");
        return;
    }
    printf("%-20s %-10s %-10s\n", "Name", "Attempts", "Time (s)");
    while (fscanf(file, "%s %d %lf", name, &attempts, &timeTaken) == 3) {
        printf("%-20s %-10d %-10.2f\n", name, attempts, timeTaken);
    }
    fclose(file);
}

int main() {
    char name[50];
    int number, guess, attempts = 0, maxNumber = 100;
    time_t startTime, endTime;
    double timeTaken;

    printf("Enter your name: ");
    scanf("%s", name);

    srand(time(NULL));
    number = rand() % maxNumber + 1;

    printf("Welcome to the Number Guessing Game!\n");
    printf("I have chosen a number between 1 and %d.\n", maxNumber);
    printf("Try to guess the number as quickly as possible.\n\n");

    time(&startTime);

    while (1) {
        printf("Enter your guess: ");
        scanf("%d", &guess);
        attempts++;

        if (guess > number) {
            printf("Too high! Try again.\n");
        } else if (guess < number) {
            printf("Too low! Try again.\n");
        } else {
            printf("Great! You guessed the number in %d attempts.\n", attempts);
            break;
        }
    }

    time(&endTime);
    timeTaken = difftime(endTime, startTime);
    printf("You took %.2f seconds to guess the number.\n", timeTaken);

    save_score(name, attempts, timeTaken);
    display_leaderboard();

    return 0;
}
